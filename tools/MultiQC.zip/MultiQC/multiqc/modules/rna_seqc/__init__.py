from __future__ import absolute_import

from .rna_seqc import MultiqcModule
