from __future__ import absolute_import

from .fastp import MultiqcModule
