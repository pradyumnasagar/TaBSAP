from __future__ import absolute_import

from .biobambam2 import MultiqcModule
